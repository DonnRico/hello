#' Language
#'
#' The data.frame `language` provides the word "hello" in different languages.
#'
#' @format
#' A `data.frame` with `r nrow(language)` rows and `r ncol(language)` columns:
#'
#' * `code`: language code: "en","fr","it","es","de", for English, 	French, Italian, Spanish, and German.
#'
#' * `hello1`: word "hello" in the language corresponding to the code.
#'
#' @author Aymeric Warnauts  <aymeric.warnauts@student.uclouvain.be>
#'
#' @source
#' <https://en.wikipedia.org/wiki/List_of_ISO_639-1_codes>
#'
#' <https://translate.google.com/>
#'
"language"

globalVariables("language") # to avoid a note about "Undefined global functions or variables" when we check() the package.
