#' Hello World
#'
#' `hello1` says _"hello"_ in the user-specified language. The user is asked to give her/his name so that the hello message gets personalized.
#'
#' @param
#' who a `character` vector of length 1 that specifies the name of the person to whom the message is addressed.
#'
#' @param
#' lang a `character` vector of length 1 that specifies the preferred language. Default to "EN" for English. Other possible values include "FR" for French, "IT"  for Italian, "ES" for Spanish, or "DE" for German. Case is ignored.
#'
#' @param
#' LangData an optional data.frame with two columns each of mode `character`. The first column gives the language codes and the second column gives the corresponding "hello" word. Default to `language`.
#'
#' see `?language`
#'
#' @return
#' a `character` vector with a personalized _"hello"_ message.
#'
#' @examples
#' hello1("Amelia", "Es")
#'
#' @export
#'
hello1 <- function(who, lang = "EN", LangData = language) {
  if (!exists("who", mode = "character") | length(who) > 1) stop("Please enter a valid namea; see ?hello1")

  LangData <- data.frame(LangData)

  if (ncol(LangData) > 2) stop("Please enter a valid LangData; see ?hello")

  colnames(LangData) <- c("code", "hello")

  if ((mode(LangData$code) != "character") | (mode(LangData$hello1) != "character")) stop("Please enter a valid LangData; see ?hello")

  llang <- tolower(lang)

  hello1 <- subset(LangData, LangData$code==llang)[[2]]

  cat(
    ifelse(
      length(hello1) == 1,
      paste(hello1, ", ", who, "!", sep = ""),
      paste("Sorry, ", who, ", ", "your language ", "('", lang, "') ", "is not available!", sep = "")
    )
  )
}
